import React from 'react';
import Client from './Client'

function App() {
  return (
    <div>
      <Client/>
    </div>
  );
}

export default App;
